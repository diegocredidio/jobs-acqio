---
title: Index
layout: default
date: 2018-11-09 19:07:01 +0000
address: Rua Domingos José Martins, 75
place: Recife, PE
zip: 50030-200

vaga: "Engenheiro de Software"
local: Recife

heading: FAÇA PARTE DO TIME DE UMA DAS FINTECHS QUE MAIS CRESCE NO BRASIL
about: |-
  Fundada por ex-funcionários da Google e Microsoft, a Acqio é uma fintech com sede em Recife (Porto Digital) e filiais em João Pessoa e São Paulo. Levamos soluções em meios de pagamentos para dezenas de milhares de clientes em todo o Brasil.

  Contamos com uma rede de venda com centenas de representantes comerciais sob o modelo de franquia e a nossa missão é levar os melhores serviços financeiros para as massas.

  Hoje, ocupamos a 21ª posição no ranking de franquias da Associação Brasileira de Franchising e estamos entre as 3 maiores microfranquias do Brasil.
form_title: "Quer se candidatar para esta vaga?"
form_subtitle: "É SUPER SIMPLES, SÓ PREENCHA O FORMULÁRIO COM OS SEUS DADOS LOGO ABAIXO:"

feature_title: Interessado em fazer parte de uma empresa que respira inovação?
feature_description: |-
  Já pensou em trabalhar com sistemas distribuídos, escaláveis e tolerantes à falha, hospedados na nuvem e com orquestração automatizada? 

  Já pensou em trabalhar para modernizar pagamentos através do uso de dispositivos móveis?

  Venha fazer parte do nosso time de Engenheiros de Software em Recife e trabalhe com:
---
